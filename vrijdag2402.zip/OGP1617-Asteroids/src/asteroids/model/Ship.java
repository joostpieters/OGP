package asteroids.model;

import asteroids.util.ModelException;

public class Ship {
	
	public Ship(double x, double y, double xVelocity,
			double yVelocity, double radius, double orientation){
		setPosition(new double[] {x,y});
		setVelocity(new double[] {xVelocity,yVelocity});
		setRadius(radius);
		setOrientation(orientation);
	}
	
	public Ship() {
		this(0,0,0,0,1,0);
	}

	public double[] getPosition() {
		// TODO Auto-generated method stub
		return position;
	}
	
	private void setPosition(double[] position) {
		this.position = position;
	}

	private double[] position = new double[2];
	
	public double[] getVelocity() {
		// TODO Auto-generated method stub
		return velocity;
	}

	private void setVelocity(double[] velocity) {
		this.velocity = velocity;
	}

	private double[] velocity = new double[2];
	
	public double getRadius() {
		// TODO Auto-generated method stub
		return radius;
	}

	private void setRadius(double radius) {
		this.radius = radius;
	}

	private double radius;
	
	public double getOrientation() {
		// TODO Auto-generated method stub
		return orientation;
	}
	
	private void setOrientation(double orientation) {
		this.orientation = orientation;
	}

	private double orientation;
	


	public void move(double dt) {
		double[] position = getPosition();
		double[] velocity = getVelocity();
		setPosition(new double[] {position[0]+velocity[0]*dt,position[1]+velocity[1]*dt});
		
	}


	public void thrust(double amount) {
		double[] velocity = getVelocity();
		double orientation = getOrientation();
		setVelocity(new double[] {velocity[0]+amount*Math.cos(orientation),velocity[1]+amount*Math.sin(orientation)});
	}


	public void turn(double angle) {
		// TODO Auto-generated method stub
		
	}


	public double getDistanceTo(Ship ship2) {
		// TODO Auto-generated method stub
		return 0;
	}


	public boolean overlapsWith(Ship ship2) {
		// TODO Auto-generated method stub
		return false;
	}


	public double getTimeToCollision(Ship ship2) {
		// TODO Auto-generated method stub
		return 0;
	}


	public double[] getCollisionPosition(Ship ship2) {
		// TODO Auto-generated method stub
		return null;
	}


}
